package com.example.ui.scene

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sim.*
import kotlin.math.hypot
import kotlin.math.min

/**
 * True 3D Isometric Cutaway Diorama Scene for Laundry Cockpit.
 * Uses foreshortened 3D cylindrical portholes, vertical 3D steam boilers & hampers,
 * multi-part 3D appliances, and 3D stylized characters in a bright, colorful theme.
 */
@OptIn(ExperimentalTextApi::class)
@Composable
fun Laundry3DScene(
    engine: SimulationEngine,
    selectedPhase: StationPhase?,
    onSelectPhase: (StationPhase) -> Unit,
    onInteractStation: ((StationPhase) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    val infiniteTransition = rememberInfiniteTransition(label = "diorama_3d_anim")
    val washerSpin by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "washer_spin"
    )
    val workerBob by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 0.20f,
        animationSpec = infiniteRepeatable(
            animation = tween(550, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "worker_bob"
    )
    val steamFloat by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1300, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "steam"
    )
    val clothesSway by infiniteTransition.animateFloat(
        initialValue = -0.18f,
        targetValue = 0.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sway"
    )
    val rainDropAnim by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rain"
    )

    val bottleneck = remember(engine.currentMinuteOfDay, engine.ordersList.size) {
        engine.diagnoseBottleneck()
    }

    val stationIsoCenters = remember {
        mapOf(
            StationPhase.CUCI to Pair(2.4f, 1.9f),
            StationPhase.JEMUR_KERING to Pair(6.8f, 1.9f),
            StationPhase.SELESAI to Pair(7.8f, 5.0f),
            StationPhase.SETRIKA to Pair(4.6f, 5.2f),
            StationPhase.MASUK to Pair(2.1f, 7.2f),
            StationPhase.PACKING to Pair(7.5f, 8.0f)
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(24.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                listOf(Color(0xFFBAE6FD), Color(0xFFA7F3D0), Color(0xFFFDE68A))
            ),
            width = 2.dp
        ),
        modifier = modifier
            .fillMaxWidth()
            .height(385.dp)
            .shadow(8.dp, RoundedCornerShape(24.dp), spotColor = Color(0x330EA5E9))
            .clip(RoundedCornerShape(24.dp))
            .testTag("laundry_3d_scene")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            val originX = w * 0.50f
                            val originY = h * 0.25f
                            val scale = min(w / 19.2f, h / 13.0f)

                            var closestPhase: StationPhase? = null
                            var minDist = Float.MAX_VALUE
                            for ((phase, coords) in stationIsoCenters) {
                                val pt = BlenderRenderer.isoPoint(originX, originY, scale, coords.first, coords.second, 0.9f)
                                val d = hypot(offset.x - pt.x, offset.y - pt.y)
                                if (d < minDist) {
                                    minDist = d
                                    closestPhase = phase
                                }
                            }

                            val tappedPhase = if (minDist <= scale * 3.2f) {
                                closestPhase
                            } else {
                                val nx = offset.x / w
                                val ny = offset.y / h
                                when {
                                    nx in 0.04f..0.42f && ny in 0.50f..0.96f -> StationPhase.MASUK
                                    nx in 0.04f..0.46f && ny in 0.10f..0.50f -> StationPhase.CUCI
                                    nx in 0.46f..0.82f && ny in 0.08f..0.48f -> StationPhase.JEMUR_KERING
                                    nx in 0.35f..0.68f && ny in 0.45f..0.85f -> StationPhase.SETRIKA
                                    nx in 0.62f..0.98f && ny in 0.55f..0.96f -> StationPhase.PACKING
                                    nx in 0.68f..0.98f && ny in 0.25f..0.60f -> StationPhase.SELESAI
                                    else -> closestPhase
                                }
                            }

                            if (tappedPhase != null) {
                                onInteractStation?.invoke(tappedPhase) ?: engine.interactWithStation(tappedPhase)
                                onSelectPhase(tappedPhase)
                            }
                        }
                    }
            ) {
                val w = size.width
                val h = size.height
                val originX = w * 0.50f
                val originY = h * 0.25f
                val scale = min(w / 19.2f, h / 13.0f)

                val bgColors = when (engine.weatherToday) {
                    Weather.CERAH -> listOf(Color(0xFFE0F2FE), Color(0xFFF0FDF4), Color(0xFFFFFBEB))
                    Weather.MENDUNG -> listOf(Color(0xFFE2E8F0), Color(0xFFF1F5F9), Color(0xFFE0F2FE))
                    Weather.HUJAN -> listOf(Color(0xFFDBEAFE), Color(0xFFE2E8F0), Color(0xFFF1F5F9))
                }
                drawRect(
                    brush = Brush.verticalGradient(bgColors),
                    topLeft = Offset.Zero,
                    size = size
                )

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x55FDE68A), Color.Transparent),
                        center = Offset(w * 0.82f, h * 0.14f),
                        radius = w * 0.45f
                    ),
                    center = Offset(w * 0.82f, h * 0.14f),
                    radius = w * 0.45f
                )

                // 1. 3D ISOMETRIC CUTAWAY DIORAMA ROOM
                drawIsoCutawayRoom3D(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    weather = engine.weatherToday,
                    rainAnim = rainDropAnim,
                    tycoonLevel = engine.tycoonLevel
                )

                // 2. 6 STATIONS IN PAINTER'S BACK-TO-FRONT DEPTH ORDER
                val isWasherRunning = engine.equipmentList.any { it.isRunning }
                val hasGasDryer = engine.equipmentList.any { it.type == AssetType.DRYER_GAS_10KG }
                val hasBoiler = engine.equipmentList.any { it.type == AssetType.SETRIKA_UAP_BOILER }

                draw3DStationCuci(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    isRunning = isWasherRunning,
                    spinAngle = washerSpin,
                    steamFloat = steamFloat,
                    ordersKg = engine.ordersList.filter { it.currentPhase == StationPhase.CUCI }.sumOf { it.weightKg },
                    isSelected = selectedPhase == StationPhase.CUCI,
                    isBottleneck = bottleneck.phase == StationPhase.CUCI,
                    textMeasurer = textMeasurer
                )

                draw3DStationKering(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    hasGasDryer = hasGasDryer,
                    clothesSway = clothesSway,
                    spinAngle = washerSpin,
                    ordersKg = engine.ordersList.filter { it.currentPhase == StationPhase.JEMUR_KERING }.sumOf { it.weightKg },
                    isSelected = selectedPhase == StationPhase.JEMUR_KERING,
                    isBottleneck = bottleneck.phase == StationPhase.JEMUR_KERING,
                    textMeasurer = textMeasurer
                )

                draw3DStationSetrika(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    hasBoiler = hasBoiler,
                    steamFloat = steamFloat,
                    ordersKg = engine.ordersList.filter { it.currentPhase == StationPhase.SETRIKA }.sumOf { it.weightKg },
                    isSelected = selectedPhase == StationPhase.SETRIKA,
                    isBottleneck = bottleneck.phase == StationPhase.SETRIKA,
                    textMeasurer = textMeasurer
                )

                draw3DStationSelesai(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    ordersKg = engine.ordersList.filter { it.currentPhase == StationPhase.SELESAI }.sumOf { it.weightKg },
                    isSelected = selectedPhase == StationPhase.SELESAI,
                    isBottleneck = bottleneck.phase == StationPhase.SELESAI,
                    textMeasurer = textMeasurer
                )

                draw3DStationMasuk(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    ordersKg = engine.ordersList.filter { it.currentPhase == StationPhase.MASUK }.sumOf { it.weightKg },
                    isSelected = selectedPhase == StationPhase.MASUK,
                    isBottleneck = bottleneck.phase == StationPhase.MASUK,
                    textMeasurer = textMeasurer
                )

                draw3DStationPacking(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    ordersKg = engine.ordersList.filter { it.currentPhase == StationPhase.PACKING }.sumOf { it.weightKg },
                    isSelected = selectedPhase == StationPhase.PACKING,
                    isBottleneck = bottleneck.phase == StationPhase.PACKING,
                    textMeasurer = textMeasurer
                )

                // 3. 3D STYLIZED CHARACTERS
                draw3DIsoCharacters(
                    originX = originX,
                    originY = originY,
                    scale = scale,
                    workers = engine.workerList,
                    bob = workerBob,
                    textMeasurer = textMeasurer
                )

                // 4. FLOATING REWARD PARTICLES
                drawFloatingParticlesClean(w, h, engine.floatingParticles, textMeasurer)
            }

            // Top-Left Clean Pastel Pill: Store Tier & Weather
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
                    .shadow(4.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.94f))
                    .border(1.dp, Color(0xFFBAE6FD), RoundedCornerShape(14.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF0EA5E9), Color(0xFF10B981)))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🏪", fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "${engine.growthTier.title} • Lv.${engine.tycoonLevel}",
                        style = TextStyle(color = Color(0xFF0F172A), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                    )
                    Text(
                        text = "${engine.weatherToday.icon} Cuaca ${engine.weatherToday.label}",
                        style = TextStyle(color = Color(0xFF0284C7), fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
                    )
                }
            }

            // Top-Right Clean Pill: Capacity & Active Combo
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (engine.taskComboCount > 1) {
                    Box(
                        modifier = Modifier
                            .shadow(4.dp, RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.horizontalGradient(listOf(Color(0xFFF43F5E), Color(0xFFF59E0B))))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "🔥 COMBO x${engine.taskComboCount}",
                            style = TextStyle(color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .shadow(4.dp, RoundedCornerShape(12.dp))
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "🚀 Target: ${engine.growthTier.maxDailyCapacityTargetKg.toInt()} kg/hari",
                        style = TextStyle(color = Color(0xFF059669), fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                    )
                }
            }

            // Bottom-Center Interactive Station Bar (Quick-Tap Pills for All 6 Stations)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .shadow(4.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.95f))
                    .border(1.dp, Color(0xFFDCEBFA), RoundedCornerShape(16.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StationPhase.values().forEach { phase ->
                    val isSel = selectedPhase == phase
                    val isBtl = bottleneck.phase == phase
                    val pillColor = Color(phase.colorHex)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                when {
                                    isSel -> pillColor
                                    isBtl -> Color(0xFFFFE4E6)
                                    else -> pillColor.copy(alpha = 0.12f)
                                }
                            )
                            .clickable {
                                onInteractStation?.invoke(phase) ?: engine.interactWithStation(phase)
                                onSelectPhase(phase)
                            }
                            .padding(horizontal = 7.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${phase.icon} ${phase.title}",
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isSel) Color.White else if (isBtl) Color(0xFFE11D48) else Color(0xFF0F172A)
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawIsoCutawayRoom3D(
    originX: Float,
    originY: Float,
    scale: Float,
    weather: Weather,
    rainAnim: Float,
    tycoonLevel: Int
) {
    // Soft ground shadow beneath the entire 3D isometric building
    val shadowPath = Path().apply {
        val s0 = BlenderRenderer.isoPoint(originX, originY + 8f, scale, 0.2f, 0.2f, -0.6f)
        val s1 = BlenderRenderer.isoPoint(originX, originY + 8f, scale, 10.3f, 0.2f, -0.6f)
        val s2 = BlenderRenderer.isoPoint(originX, originY + 8f, scale, 10.3f, 10.3f, -0.6f)
        val s3 = BlenderRenderer.isoPoint(originX, originY + 8f, scale, 0.2f, 10.3f, -0.6f)
        moveTo(s0.x, s0.y)
        lineTo(s1.x, s1.y)
        lineTo(s2.x, s2.y)
        lineTo(s3.x, s3.y)
        close()
    }
    drawPath(shadowPath, color = Color(0x220284C7))

    // 1A. 3D Floor Foundation Slab (x=0..10, y=0..10, z=-0.55..0)
    BlenderRenderer.drawIsoBox(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        x = 0f, y = 0f, z = -0.55f,
        dx = 10f, dy = 10f, dz = 0.55f,
        topColor = Color(0xFFF8FAFC),
        leftColor = Color(0xFF38BDF8),
        rightColor = Color(0xFF0284C7),
        strokeColor = Color.White.copy(alpha = 0.5f)
    )

    // 1B. 3D Isometric Checkerboard Ceramic Tiles (10x10 grid)
    val tileLight = Color(0xFFFFFFFF)
    val tileAccent = if (tycoonLevel >= 2) Color(0xFFD1FAE5) else Color(0xFFE0F2FE)
    val tileBorder = Color(0xFFBAE6FD).copy(alpha = 0.45f)

    for (ix in 0 until 10) {
        for (iy in 0 until 10) {
            val p0 = BlenderRenderer.isoPoint(originX, originY, scale, ix.toFloat(), iy.toFloat(), 0f)
            val p1 = BlenderRenderer.isoPoint(originX, originY, scale, ix + 1f, iy.toFloat(), 0f)
            val p2 = BlenderRenderer.isoPoint(originX, originY, scale, ix + 1f, iy + 1f, 0f)
            val p3 = BlenderRenderer.isoPoint(originX, originY, scale, ix.toFloat(), iy + 1f, 0f)
            val tPath = Path().apply {
                moveTo(p0.x, p0.y)
                lineTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(p3.x, p3.y)
                close()
            }
            val color = if ((ix + iy) % 2 == 0) tileLight else tileAccent
            drawPath(tPath, color = color)
            drawPath(tPath, color = tileBorder, style = Stroke(width = 0.7f))
        }
    }

    val wallH = 3.8f
    val wallThick = 0.35f

    // Left Cutaway Wall (runs along Y axis at X = 0)
    BlenderRenderer.drawIsoBox(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        x = -wallThick, y = -wallThick, z = 0f,
        dx = wallThick, dy = 10f + wallThick, dz = wallH,
        topColor = Color(0xFFBAE6FD),
        leftColor = Color(0xFF7DD3FC),
        rightColor = Color(0xFFF0F9FF),
        strokeColor = Color(0xFF93C5FD)
    )
    // Left Wall Mint Baseboard Trim
    BlenderRenderer.drawIsoBox(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        x = 0f, y = 0f, z = 0f,
        dx = 0.08f, dy = 10f, dz = 0.35f,
        topColor = Color(0xFF34D399),
        leftColor = Color(0xFF10B981),
        rightColor = Color(0xFF10B981),
        strokeColor = null
    )

    // Right Cutaway Wall (runs along X axis at Y = 0)
    BlenderRenderer.drawIsoBox(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        x = 0f, y = -wallThick, z = 0f,
        dx = 10f, dy = wallThick, dz = wallH,
        topColor = Color(0xFFBAE6FD),
        leftColor = Color(0xFFE0F2FE),
        rightColor = Color(0xFF7DD3FC),
        strokeColor = Color(0xFF93C5FD)
    )
    // Right Wall Mint Baseboard Trim
    BlenderRenderer.drawIsoBox(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        x = 0f, y = 0f, z = 0f,
        dx = 10f, dy = 0.08f, dz = 0.35f,
        topColor = Color(0xFF34D399),
        leftColor = Color(0xFF059669),
        rightColor = Color(0xFF10B981),
        strokeColor = null
    )

    // 3D Isometric Window on Right Wall
    val w0 = BlenderRenderer.isoPoint(originX, originY, scale, 4.6f, 0.06f, 1.3f)
    val w1 = BlenderRenderer.isoPoint(originX, originY, scale, 8.4f, 0.06f, 1.3f)
    val w2 = BlenderRenderer.isoPoint(originX, originY, scale, 8.4f, 0.06f, 3.3f)
    val w3 = BlenderRenderer.isoPoint(originX, originY, scale, 4.6f, 0.06f, 3.3f)
    val winPath = Path().apply {
        moveTo(w0.x, w0.y)
        lineTo(w1.x, w1.y)
        lineTo(w2.x, w2.y)
        lineTo(w3.x, w3.y)
        close()
    }
    val skyColors = when (weather) {
        Weather.CERAH -> listOf(Color(0xFF38BDF8), Color(0xFFBAE6FD))
        Weather.MENDUNG -> listOf(Color(0xFF94A3B8), Color(0xFFCBD5E1))
        Weather.HUJAN -> listOf(Color(0xFF64748B), Color(0xFF94A3B8))
    }
    drawPath(winPath, brush = Brush.verticalGradient(skyColors, startY = w3.y, endY = w0.y))
    if (weather == Weather.CERAH) {
        val sunCenter = BlenderRenderer.isoPoint(originX, originY, scale, 7.3f, 0.06f, 2.7f)
        drawCircle(Color(0xFFFFE066), radius = scale * 0.45f, center = sunCenter)
    } else if (weather == Weather.HUJAN) {
        for (r in 0..5) {
            val rx = 5.0f + r * 0.6f
            val rz = 3.1f - ((rainAnim + r * 0.18f) % 1.0f) * 1.5f
            val rs = BlenderRenderer.isoPoint(originX, originY, scale, rx, 0.06f, rz)
            val re = BlenderRenderer.isoPoint(originX, originY, scale, rx - 0.15f, 0.06f, rz - 0.35f)
            drawLine(Color.White.copy(alpha = 0.85f), rs, re, strokeWidth = 2f)
        }
    }
    drawPath(winPath, color = Color.White, style = Stroke(width = 3f))

    // 3D Detergent Wall Shelf & Cylindrical Bottles on Left Wall
    BlenderRenderer.drawIsoBox(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        x = 0.05f, y = 1.4f, z = 2.2f,
        dx = 0.45f, dy = 2.8f, dz = 0.16f,
        topColor = Color(0xFFFDE68A),
        leftColor = Color(0xFFF59E0B),
        rightColor = Color(0xFFD97706)
    )
    val bottleColors = listOf(Color(0xFFF43F5E), Color(0xFF0EA5E9), Color(0xFF10B981), Color(0xFF8B5CF6))
    for (b in 0..3) {
        val bc = bottleColors[b]
        BlenderRenderer.drawIsoVerticalCylinder(
            drawScope = this,
            originX = originX,
            originY = originY,
            scale = scale,
            centerX = 0.28f,
            centerY = 1.80f + b * 0.62f,
            baseZ = 2.36f,
            radius = 0.16f,
            height = 0.50f,
            topColor = BlenderLighting.highlightColor(bc, 0.35f),
            bodyColor = bc
        )
    }

    // 3D Isometric Store Signboard on Right Wall
    BlenderRenderer.drawIsoBox(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        x = 0.7f, y = 0.05f, z = 2.35f,
        dx = 3.4f, dy = 0.22f, dz = 0.95f,
        topColor = Color(0xFFFDE68A),
        leftColor = Color(0xFF0EA5E9),
        rightColor = Color(0xFF0284C7),
        strokeColor = Color(0xFFFBBF24),
        strokeWidth = 1.8f
    )
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.draw3DStationCuci(
    originX: Float,
    originY: Float,
    scale: Float,
    isRunning: Boolean,
    spinAngle: Float,
    steamFloat: Float,
    ordersKg: Double,
    isSelected: Boolean,
    isBottleneck: Boolean,
    textMeasurer: TextMeasurer
) {
    draw3DStationPad(
        originX, originY, scale,
        x = 0.8f, y = 0.7f, dx = 3.4f, dy = 2.4f,
        padColor = if (isBottleneck) Color(0xFFFFE4E6) else Color(0xFFE0F2FE),
        borderColor = if (isBottleneck) Color(0xFFF43F5E) else if (isSelected) Color(0xFF0EA5E9) else Color(0xFF7DD3FC)
    )

    val washerPositions = listOf(1.05f, 2.55f)
    washerPositions.forEachIndexed { idx, wx ->
        val wy = 0.95f
        // Pedestal
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = wx, y = wy, z = 0f,
            dx = 1.25f, dy = 1.25f, dz = 0.22f,
            topColor = Color(0xFFCBD5E1),
            leftColor = Color(0xFF94A3B8),
            rightColor = Color(0xFF64748B)
        )
        // Main Cabinet
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = wx, y = wy, z = 0.22f,
            dx = 1.25f, dy = 1.25f, dz = 1.45f,
            topColor = Color(0xFFFFFFFF),
            leftColor = Color(0xFFF8FAFC),
            rightColor = Color(0xFFE2E8F0),
            strokeColor = Color(0xFFBAE6FD)
        )
        // Top Control Fascia
        val topAccent = if (idx == 0) Color(0xFF0EA5E9) else Color(0xFF06B6D4)
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = wx, y = wy, z = 1.67f,
            dx = 1.25f, dy = 1.25f, dz = 0.32f,
            topColor = BlenderLighting.highlightColor(topAccent, 0.35f),
            leftColor = topAccent,
            rightColor = BlenderLighting.shadeColor(topAccent, 0.82f)
        )

        // True 3D Foreshortened Isometric Drum Porthole on the +Y Front Face
        BlenderRenderer.drawIsoPortholeOnYFace(
            drawScope = this,
            originX = originX,
            originY = originY,
            scale = scale,
            centerX = wx + 0.62f,
            faceY = wy + 1.25f,
            centerZ = 0.95f,
            radius = 0.42f,
            extrudeY = 0.14f,
            rimColor = topAccent,
            glassColor = if (isRunning) Color(0xFF0284C7) else Color(0xFF1E293B),
            swirlColor = if (isRunning) Color(0xFF7DD3FC) else null,
            spinDeg = spinAngle + idx * 90f
        )

        if (isRunning) {
            val bubblePos = BlenderRenderer.isoPoint(originX, originY, scale, wx + 0.6f, wy + 0.6f, 2.1f + steamFloat * 0.7f)
            drawCircle(Color(0xCCBAE6FD), radius = 5f, center = bubblePos)
            drawCircle(Color.White, radius = 2f, center = Offset(bubblePos.x - 1.5f, bubblePos.y - 1.5f))
        }
    }

    val badgePos = BlenderRenderer.isoPoint(originX, originY, scale, 2.4f, 1.5f, 2.55f)
    drawClean3DBadge(badgePos.x, badgePos.y, "🫧 Cuci", "${ordersKg.toInt()} kg", if (isBottleneck) Color(0xFFF43F5E) else Color(0xFF0EA5E9), textMeasurer)
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.draw3DStationKering(
    originX: Float,
    originY: Float,
    scale: Float,
    hasGasDryer: Boolean,
    clothesSway: Float,
    spinAngle: Float,
    ordersKg: Double,
    isSelected: Boolean,
    isBottleneck: Boolean,
    textMeasurer: TextMeasurer
) {
    draw3DStationPad(
        originX, originY, scale,
        x = 5.2f, y = 0.7f, dx = 3.8f, dy = 2.4f,
        padColor = if (isBottleneck) Color(0xFFFFE4E6) else Color(0xFFFEF3C7),
        borderColor = if (isBottleneck) Color(0xFFF43F5E) else if (isSelected) Color(0xFFF59E0B) else Color(0xFFFDE68A)
    )

    if (hasGasDryer) {
        listOf(5.5f, 7.1f).forEachIndexed { idx, dxPos ->
            val dyPos = 0.95f
            BlenderRenderer.drawIsoBox(
                this, originX, originY, scale,
                x = dxPos, y = dyPos, z = 0f,
                dx = 1.3f, dy = 1.3f, dz = 1.75f,
                topColor = Color(0xFFFFFBEB),
                leftColor = Color(0xFFFEF3C7),
                rightColor = Color(0xFFFDE68A),
                strokeColor = Color(0xFFF59E0B)
            )
            BlenderRenderer.drawIsoBox(
                this, originX, originY, scale,
                x = dxPos, y = dyPos, z = 1.75f,
                dx = 1.3f, dy = 1.3f, dz = 0.35f,
                topColor = Color(0xFFFBBF24),
                leftColor = Color(0xFFF59E0B),
                rightColor = Color(0xFFD97706)
            )
            BlenderRenderer.drawIsoPortholeOnYFace(
                drawScope = this,
                originX = originX,
                originY = originY,
                scale = scale,
                centerX = dxPos + 0.65f,
                faceY = dyPos + 1.30f,
                centerZ = 0.95f,
                radius = 0.44f,
                extrudeY = 0.14f,
                rimColor = Color(0xFFD97706),
                glassColor = Color(0xFFF59E0B),
                swirlColor = Color(0xFFFEF08A),
                spinDeg = -spinAngle + idx * 60f
            )
        }
    } else {
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = 5.5f, y = 1.6f, z = 0f,
            dx = 0.25f, dy = 0.25f, dz = 2.1f,
            topColor = Color(0xFFFBBF24), leftColor = Color(0xFFD97706), rightColor = Color(0xFFB45309)
        )
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = 8.4f, y = 1.6f, z = 0f,
            dx = 0.25f, dy = 0.25f, dz = 2.1f,
            topColor = Color(0xFFFBBF24), leftColor = Color(0xFFD97706), rightColor = Color(0xFFB45309)
        )
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = 5.45f, y = 1.58f, z = 2.1f,
            dx = 3.25f, dy = 0.30f, dz = 0.20f,
            topColor = Color(0xFFFDE68A), leftColor = Color(0xFFF59E0B), rightColor = Color(0xFFD97706)
        )
        val shirtColors = listOf(Color(0xFFF43F5E), Color(0xFF0EA5E9), Color(0xFF10B981), Color(0xFF8B5CF6))
        for (i in 0..3) {
            val sc = shirtColors[i]
            val sx = 5.9f + i * 0.62f
            BlenderRenderer.drawIsoBox(
                this, originX, originY, scale,
                x = sx, y = 1.65f + clothesSway * (if (i % 2 == 0) 1f else -1f), z = 0.85f,
                dx = 0.44f, dy = 0.16f, dz = 1.20f,
                topColor = BlenderLighting.highlightColor(sc, 0.3f),
                leftColor = sc,
                rightColor = BlenderLighting.shadeColor(sc, 0.8f)
            )
        }
    }

    val badgePos = BlenderRenderer.isoPoint(originX, originY, scale, 7.0f, 1.5f, 2.55f)
    drawClean3DBadge(
        badgePos.x, badgePos.y,
        if (hasGasDryer) "🔥 Dryer Gas" else "☀️ Jemur",
        "${ordersKg.toInt()} kg",
        if (isBottleneck) Color(0xFFF43F5E) else Color(0xFFF59E0B),
        textMeasurer
    )
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.draw3DStationSetrika(
    originX: Float,
    originY: Float,
    scale: Float,
    hasBoiler: Boolean,
    steamFloat: Float,
    ordersKg: Double,
    isSelected: Boolean,
    isBottleneck: Boolean,
    textMeasurer: TextMeasurer
) {
    draw3DStationPad(
        originX, originY, scale,
        x = 3.4f, y = 4.0f, dx = 2.8f, dy = 2.5f,
        padColor = if (isBottleneck) Color(0xFFFFE4E6) else Color(0xFFFFF1F2),
        borderColor = if (isBottleneck || isSelected) Color(0xFFF43F5E) else Color(0xFFFECDD3)
    )

    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 3.8f, y = 4.6f, z = 0f,
        dx = 0.22f, dy = 0.9f, dz = 1.0f,
        topColor = Color(0xFFCBD5E1), leftColor = Color(0xFF94A3B8), rightColor = Color(0xFF64748B)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 5.3f, y = 4.6f, z = 0f,
        dx = 0.22f, dy = 0.9f, dz = 1.0f,
        topColor = Color(0xFFCBD5E1), leftColor = Color(0xFF94A3B8), rightColor = Color(0xFF64748B)
    )

    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 3.65f, y = 4.45f, z = 1.0f,
        dx = 2.0f, dy = 1.15f, dz = 0.24f,
        topColor = Color(0xFFF43F5E),
        leftColor = Color(0xFFE11D48),
        rightColor = Color(0xFFBE123C)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 3.95f, y = 4.65f, z = 1.24f,
        dx = 0.95f, dy = 0.75f, dz = 0.10f,
        topColor = Color(0xFFFEF08A),
        leftColor = Color(0xFFFACC15),
        rightColor = Color(0xFFEAB308)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 4.95f, y = 4.75f, z = 1.24f,
        dx = 0.42f, dy = 0.35f, dz = 0.28f,
        topColor = Color.White,
        leftColor = Color(0xFF38BDF8),
        rightColor = Color(0xFF0284C7)
    )

    // True 3D Cylindrical Steam Boiler Tank beside table
    val boilerColor = if (hasBoiler) Color(0xFFF59E0B) else Color(0xFFFB7185)
    BlenderRenderer.drawIsoVerticalCylinder(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        centerX = 5.85f,
        centerY = 4.55f,
        baseZ = 0f,
        radius = 0.28f,
        height = if (hasBoiler) 1.45f else 1.0f,
        topColor = BlenderLighting.highlightColor(boilerColor, 0.35f),
        bodyColor = boilerColor
    )

    val s1 = BlenderRenderer.isoPoint(originX, originY, scale, 5.1f, 4.8f, 1.6f + steamFloat * 0.7f)
    val s2 = BlenderRenderer.isoPoint(originX, originY, scale, 4.8f, 4.9f, 1.9f + steamFloat * 0.9f)
    drawCircle(Color.White.copy(alpha = (1f - steamFloat) * 0.85f), radius = scale * 0.26f, center = s1)
    drawCircle(Color.White.copy(alpha = (1f - steamFloat) * 0.65f), radius = scale * 0.34f, center = s2)

    val badgePos = BlenderRenderer.isoPoint(originX, originY, scale, 4.8f, 4.8f, 2.25f)
    drawClean3DBadge(badgePos.x, badgePos.y, "💨 Setrika", "${ordersKg.toInt()} kg", Color(0xFFF43F5E), textMeasurer)
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.draw3DStationSelesai(
    originX: Float,
    originY: Float,
    scale: Float,
    ordersKg: Double,
    isSelected: Boolean,
    isBottleneck: Boolean,
    textMeasurer: TextMeasurer
) {
    draw3DStationPad(
        originX, originY, scale,
        x = 6.7f, y = 3.7f, dx = 2.7f, dy = 2.4f,
        padColor = Color(0xFFCCFBF1),
        borderColor = if (isSelected) Color(0xFF14B8A6) else Color(0xFF99F6E4)
    )

    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 7.0f, y = 4.0f, z = 0f,
        dx = 2.1f, dy = 1.6f, dz = 0.45f,
        topColor = Color(0xFF99F6E4),
        leftColor = Color(0xFF14B8A6),
        rightColor = Color(0xFF0D9488)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 7.1f, y = 4.5f, z = 0.45f,
        dx = 0.16f, dy = 0.16f, dz = 1.55f,
        topColor = Color.White, leftColor = Color(0xFFCBD5E1), rightColor = Color(0xFF94A3B8)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 8.8f, y = 4.5f, z = 0.45f,
        dx = 0.16f, dy = 0.16f, dz = 1.55f,
        topColor = Color.White, leftColor = Color(0xFFCBD5E1), rightColor = Color(0xFF94A3B8)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 7.08f, y = 4.48f, z = 2.0f,
        dx = 1.90f, dy = 0.20f, dz = 0.14f,
        topColor = Color(0xFFFDE68A), leftColor = Color(0xFFF59E0B), rightColor = Color(0xFFD97706)
    )
    val bagColors = listOf(Color(0xFF10B981), Color(0xFF0EA5E9), Color(0xFF8B5CF6))
    for (b in 0..2) {
        val bc = bagColors[b]
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = 7.35f + b * 0.46f, y = 4.35f, z = 0.65f,
            dx = 0.36f, dy = 0.48f, dz = 1.25f,
            topColor = BlenderLighting.highlightColor(bc, 0.35f),
            leftColor = bc,
            rightColor = BlenderLighting.shadeColor(bc, 0.82f)
        )
    }

    val badgePos = BlenderRenderer.isoPoint(originX, originY, scale, 8.0f, 4.6f, 2.55f)
    drawClean3DBadge(badgePos.x, badgePos.y, "✨ Selesai", "${ordersKg.toInt()} kg", Color(0xFF0D9488), textMeasurer)
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.draw3DStationMasuk(
    originX: Float,
    originY: Float,
    scale: Float,
    ordersKg: Double,
    isSelected: Boolean,
    isBottleneck: Boolean,
    textMeasurer: TextMeasurer
) {
    draw3DStationPad(
        originX, originY, scale,
        x = 0.8f, y = 5.6f, dx = 3.0f, dy = 3.2f,
        padColor = if (isBottleneck) Color(0xFFFFE4E6) else Color(0xFFD1FAE5),
        borderColor = if (isBottleneck) Color(0xFFF43F5E) else if (isSelected) Color(0xFF10B981) else Color(0xFFA7F3D0)
    )

    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 1.0f, y = 6.0f, z = 0f,
        dx = 2.2f, dy = 1.25f, dz = 1.05f,
        topColor = Color(0xFFFFFFFF),
        leftColor = Color(0xFF10B981),
        rightColor = Color(0xFF059669)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 0.95f, y = 5.95f, z = 1.05f,
        dx = 2.3f, dy = 1.35f, dz = 0.18f,
        topColor = Color(0xFFFFFBEB),
        leftColor = Color(0xFFFDE68A),
        rightColor = Color(0xFFF59E0B)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 1.2f, y = 6.25f, z = 1.23f,
        dx = 0.75f, dy = 0.75f, dz = 0.25f,
        topColor = Color(0xFF34D399),
        leftColor = Color(0xFF1E293B),
        rightColor = Color(0xFF0F172A)
    )
    // True 3D Cylindrical Laundry Hamper with Colorful Mound
    BlenderRenderer.drawIsoVerticalCylinder(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        centerX = 2.75f,
        centerY = 7.95f,
        baseZ = 0f,
        radius = 0.52f,
        height = 0.85f,
        topColor = Color(0xFFFDA4AF),
        bodyColor = Color(0xFF0EA5E9)
    )

    val badgePos = BlenderRenderer.isoPoint(originX, originY, scale, 2.1f, 6.6f, 2.15f)
    drawClean3DBadge(badgePos.x, badgePos.y, "🧺 Masuk", "${ordersKg.toInt()} kg", if (isBottleneck) Color(0xFFF43F5E) else Color(0xFF10B981), textMeasurer)
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.draw3DStationPacking(
    originX: Float,
    originY: Float,
    scale: Float,
    ordersKg: Double,
    isSelected: Boolean,
    isBottleneck: Boolean,
    textMeasurer: TextMeasurer
) {
    draw3DStationPad(
        originX, originY, scale,
        x = 5.8f, y = 6.6f, dx = 3.4f, dy = 2.6f,
        padColor = Color(0xFFEDE9FE),
        borderColor = if (isSelected) Color(0xFF8B5CF6) else Color(0xFFDDD6FE)
    )

    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 6.1f, y = 7.0f, z = 0f,
        dx = 2.6f, dy = 1.55f, dz = 1.0f,
        topColor = Color(0xFFFFFFFF),
        leftColor = Color(0xFF8B5CF6),
        rightColor = Color(0xFF7C3AED)
    )
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = 6.05f, y = 6.95f, z = 1.0f,
        dx = 2.7f, dy = 1.65f, dz = 0.18f,
        topColor = Color(0xFFF5F3FF),
        leftColor = Color(0xFFDDD6FE),
        rightColor = Color(0xFFC4B5FD)
    )
    val stackColors = listOf(Color(0xFFEC4899), Color(0xFF38BDF8), Color(0xFFFBBF24))
    stackColors.forEachIndexed { idx, sc ->
        BlenderRenderer.drawIsoBox(
            this, originX, originY, scale,
            x = 6.35f + idx * 0.72f, y = 7.25f, z = 1.18f,
            dx = 0.58f, dy = 0.68f, dz = 0.35f + (idx % 2) * 0.15f,
            topColor = BlenderLighting.highlightColor(sc, 0.3f),
            leftColor = sc,
            rightColor = BlenderLighting.shadeColor(sc, 0.82f)
        )
    }

    val badgePos = BlenderRenderer.isoPoint(originX, originY, scale, 7.4f, 7.6f, 2.15f)
    drawClean3DBadge(badgePos.x, badgePos.y, "📦 Packing", "${ordersKg.toInt()} kg", Color(0xFF8B5CF6), textMeasurer)
}

private fun DrawScope.draw3DStationPad(
    originX: Float,
    originY: Float,
    scale: Float,
    x: Float,
    y: Float,
    dx: Float,
    dy: Float,
    padColor: Color,
    borderColor: Color
) {
    val p0 = BlenderRenderer.isoPoint(originX, originY, scale, x, y, 0.02f)
    val p1 = BlenderRenderer.isoPoint(originX, originY, scale, x + dx, y, 0.02f)
    val p2 = BlenderRenderer.isoPoint(originX, originY, scale, x + dx, y + dy, 0.02f)
    val p3 = BlenderRenderer.isoPoint(originX, originY, scale, x, y + dy, 0.02f)
    val path = Path().apply {
        moveTo(p0.x, p0.y)
        lineTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        lineTo(p3.x, p3.y)
        close()
    }
    drawPath(path, color = padColor.copy(alpha = 0.82f))
    drawPath(path, color = borderColor, style = Stroke(width = 2.0f))
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.draw3DIsoCharacters(
    originX: Float,
    originY: Float,
    scale: Float,
    workers: List<WorkerStaff>,
    bob: Float,
    textMeasurer: TextMeasurer
) {
    drawSingle3DIsoCharacter(
        originX = originX,
        originY = originY,
        scale = scale,
        x = 1.25f,
        y = 8.15f,
        zBob = bob * 0.5f,
        outfitColor = Color(0xFFEC4899),
        capColor = Color(0xFFF472B6),
        label = "Pelanggan 🧺",
        textMeasurer = textMeasurer
    )

    workers.forEachIndexed { index, worker ->
        val (wx, wy) = when (worker.assignedPhase) {
            StationPhase.MASUK -> Pair(2.6f, 6.5f)
            StationPhase.CUCI -> Pair(2.1f + (index % 2) * 1.1f, 3.3f)
            StationPhase.JEMUR_KERING -> Pair(6.5f + (index % 2) * 1.1f, 3.3f)
            StationPhase.SETRIKA -> Pair(4.2f + (index % 2) * 1.0f, 6.1f)
            StationPhase.PACKING -> Pair(7.2f, 8.8f)
            StationPhase.SELESAI -> Pair(7.8f, 6.1f)
        }
        val zAnim = if (index % 2 == 0) bob else (0.20f - bob)
        val outfit = Color(worker.avatarColor)
        drawSingle3DIsoCharacter(
            originX = originX,
            originY = originY,
            scale = scale,
            x = wx,
            y = wy,
            zBob = zAnim,
            outfitColor = outfit,
            capColor = BlenderLighting.highlightColor(outfit, 0.25f),
            label = "${worker.name.substringBefore(" ")} ${worker.moodEmoji}",
            textMeasurer = textMeasurer
        )
    }
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawSingle3DIsoCharacter(
    originX: Float,
    originY: Float,
    scale: Float,
    x: Float,
    y: Float,
    zBob: Float,
    outfitColor: Color,
    capColor: Color,
    label: String,
    textMeasurer: TextMeasurer
) {
    val groundPt = BlenderRenderer.isoPoint(originX, originY, scale, x + 0.25f, y + 0.25f, 0.03f)
    drawOval(
        color = Color(0x330F172A),
        topLeft = Offset(groundPt.x - scale * 0.42f, groundPt.y - scale * 0.20f),
        size = Size(scale * 0.84f, scale * 0.40f)
    )

    // 1. 3D Shoes/Legs
    BlenderRenderer.drawIsoBox(
        this, originX, originY, scale,
        x = x, y = y, z = zBob,
        dx = 0.42f, dy = 0.42f, dz = 0.35f,
        topColor = Color(0xFF475569),
        leftColor = Color(0xFF334155),
        rightColor = Color(0xFF1E293B)
    )
    // 2. 3D Cylindrical Torso & Apron
    BlenderRenderer.drawIsoVerticalCylinder(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        centerX = x + 0.21f,
        centerY = y + 0.21f,
        baseZ = zBob + 0.35f,
        radius = 0.28f,
        height = 0.62f,
        topColor = BlenderLighting.highlightColor(outfitColor, 0.28f),
        bodyColor = outfitColor
    )
    // 3. 3D Stylized Head
    BlenderRenderer.drawIsoVerticalCylinder(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        centerX = x + 0.21f,
        centerY = y + 0.21f,
        baseZ = zBob + 0.97f,
        radius = 0.25f,
        height = 0.46f,
        topColor = Color(0xFFFFE4C4),
        bodyColor = Color(0xFFFFDAB9)
    )
    // 4. 3D Cap / Hair
    BlenderRenderer.drawIsoVerticalCylinder(
        drawScope = this,
        originX = originX,
        originY = originY,
        scale = scale,
        centerX = x + 0.21f,
        centerY = y + 0.21f,
        baseZ = zBob + 1.43f,
        radius = 0.27f,
        height = 0.16f,
        topColor = capColor,
        bodyColor = outfitColor
    )

    val headTop = BlenderRenderer.isoPoint(originX, originY, scale, x + 0.21f, y + 0.21f, zBob + 1.85f)
    val textResult = textMeasurer.measure(
        AnnotatedString(label),
        style = TextStyle(fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0F172A))
    )
    val bw = textResult.size.width + 12f
    val bh = textResult.size.height + 5f
    val bx = headTop.x - bw / 2f
    val by = headTop.y - bh / 2f

    drawRoundRect(
        color = Color(0x260F172A),
        topLeft = Offset(bx + 1f, by + 2f),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(8f, 8f)
    )
    drawRoundRect(
        color = Color.White,
        topLeft = Offset(bx, by),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(8f, 8f)
    )
    drawRoundRect(
        color = outfitColor,
        topLeft = Offset(bx, by),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(8f, 8f),
        style = Stroke(width = 1.2f)
    )
    drawText(
        textMeasurer = textMeasurer,
        text = label,
        topLeft = Offset(bx + 6f, by + 2.5f),
        style = TextStyle(fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0F172A))
    )
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawClean3DBadge(
    centerX: Float,
    centerY: Float,
    title: String,
    value: String,
    accentColor: Color,
    textMeasurer: TextMeasurer
) {
    val label = "$title • $value"
    val textResult = textMeasurer.measure(
        AnnotatedString(label),
        style = TextStyle(fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
    )
    val bw = textResult.size.width + 16f
    val bh = textResult.size.height + 7f
    val bx = centerX - bw / 2f
    val by = centerY - bh / 2f

    drawRoundRect(
        color = Color(0x330F172A),
        topLeft = Offset(bx + 1.5f, by + 2.5f),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(10f, 10f)
    )
    drawRoundRect(
        color = accentColor,
        topLeft = Offset(bx, by),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(10f, 10f)
    )
    drawRoundRect(
        color = Color.White.copy(alpha = 0.85f),
        topLeft = Offset(bx, by),
        size = Size(bw, bh),
        cornerRadius = CornerRadius(10f, 10f),
        style = Stroke(width = 1.4f)
    )
    drawText(
        textMeasurer = textMeasurer,
        text = label,
        topLeft = Offset(bx + 8f, by + 3.5f),
        style = TextStyle(fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
    )
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawFloatingParticlesClean(
    w: Float,
    h: Float,
    particles: List<FloatingParticle>,
    textMeasurer: TextMeasurer
) {
    val now = System.currentTimeMillis()
    particles.forEach { p ->
        val elapsed = (now - p.timestamp).toFloat().coerceIn(0f, 2500f)
        val progress = elapsed / 2500f
        val alpha = (1f - progress).coerceIn(0f, 1f)
        val floatUpY = (p.yRatio * h) - (progress * 55f)
        val posX = p.xRatio * w

        val textResult = textMeasurer.measure(
            AnnotatedString(p.text),
            style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color.White.copy(alpha = alpha))
        )
        val bw = textResult.size.width + 16f
        val bh = textResult.size.height + 8f

        drawRoundRect(
            color = Color(p.colorHex).copy(alpha = alpha * 0.95f),
            topLeft = Offset(posX - bw / 2f, floatUpY - bh / 2f),
            size = Size(bw, bh),
            cornerRadius = CornerRadius(12f, 12f)
        )
        drawRoundRect(
            color = Color.White.copy(alpha = alpha),
            topLeft = Offset(posX - bw / 2f, floatUpY - bh / 2f),
            size = Size(bw, bh),
            cornerRadius = CornerRadius(12f, 12f),
            style = Stroke(width = 1.5f)
        )
        drawText(
            textMeasurer = textMeasurer,
            text = p.text,
            topLeft = Offset(posX - textResult.size.width / 2f, floatUpY - textResult.size.height / 2f),
            style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color.White.copy(alpha = alpha))
        )
    }
}
