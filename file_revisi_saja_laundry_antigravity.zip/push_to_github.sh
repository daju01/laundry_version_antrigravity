#!/usr/bin/env bash
set -e
if [ -z "$1" ]; then
  echo "Usage: ./push_to_github.sh https://github.com/<username>/<repo>.git"
  exit 1
fi
REMOTE_URL="$1"
git branch -M main
if git remote | grep -q "^origin$"; then
  git remote set-url origin "$REMOTE_URL"
else
  git remote add origin "$REMOTE_URL"
fi
git push -u origin main
echo "✅ Berhasil di-push ke $REMOTE_URL (branch: main)!"
