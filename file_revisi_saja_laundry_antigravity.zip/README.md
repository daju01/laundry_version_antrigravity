# 🧺 Laundry Cockpit — 3D Tycoon & Business ERP Simulator (Antigravity Edition)

Aplikasi Android berbasis **Jetpack Compose** yang menggabungkan **Game Simulasi 3D Isometric Laundry Tycoon** (lengkap dengan *procedural Blender-style 3D mesh shader* & *16-bit PCM audio synthesizer*) dan **Executive Business Cockpit & What-If ERP Simulator** untuk pemilik usaha laundry kiloan.

## ✨ Fitur Utama

1. **🎮 3D Isometric Laundry Tycoon (`MainGameCockpitScreen` & `Laundry3DScene`)**
   - Visualisasi workshop 3D isometrik interaktif (6 stasiun: *Masuk, Cuci, Jemur/Kering, Setrika, Packing, Selesai*).
   - **Procedural Blender-Style 3D Shader (`Blender3DEngine`)**: Pencahayaan *Blinn-Phong*, *backface culling*, *ambient occlusion*, dan transisi 3D saat ekspansi kapasitas naik level.
   - **Procedural Audio & Haptic Engine (`GameSoundManager`)**: Efek suara PCM 16-bit murni di memori tanpa file audio eksternal.
   - **Manajemen Operasional & Lab Sandbox**: Uji skenario investasi Dryer Gas, rekrutmen staf, dan lembur tanpa risiko di *Lab Mode*.

2. **📊 Business ERP Cockpit & What-If Simulator (`CockpitScreen`, `OperasiScreen`, `KeuanganScreen`, `SimulatorScreen`, `SettingScreen`)**
   - **Deteksi Bottleneck Dinamis**: Analisis utilisasi kapasitas *real-time* di tahap Cuci, Kering, dan Setrika.
   - **Unit Economics & Break-Even Point (BEP)**: Kalkulasi HPP/kg, *contribution margin*, BEP harian/bulanan, proyeksi *cashflow* 12 bulan, dan *Customer Lifetime Value (CLV)*.
   - **1-Tap Sync (`🔄 Sync Game➔ERP`)**: Sinkronkan kondisi peralatan, pekerja, kuota, kas, dan order dari simulasi 3D langsung ke kalkulator ERP.

## 🛠️ Perbaikan Audit yang Telah Diterapkan

Lihat detail lengkap di [`AUDIT_REPORT.md`](./AUDIT_REPORT.md):
- Perbaikan bug *StateFlow structural-equality conflation* pada `GameCockpitViewModel` menggunakan counter monotonik `stateRevision`.
- Penyatuan navigasi `MainActivity` (`WorkspaceModeSwitcherBar` + sinkronisasi 2 arah `NavGameTab`) sehingga seluruh 5 layar ERP dan modal input order dapat diakses penuh.
- Penambahan tombol HUD manajemen (`🏪 Toko Alat & Staf`, `🧪 Uji Lab`, `🌙 Tutup Hari`) di `CockpitHeaderBar`.
- Sinkronisasi penuh antara siklus mesin cuci (`remainingMinutesInCycle`) dan durasi order (`minutesInCurrentPhase`), dukungan kenaikan *multi-level XP*, dan pencatatan biaya booster ke laporan laba-rugi harian.
- Perbaikan batas dinamis `Slider` kuota pagi di `MorningPlanningDialog` untuk Level 3–5 (80–200 kg/hari).

## 🚀 Cara Push ke GitHub

Repositori ini sudah diinisialisasi dengan Git (`.git`) beserta riwayat *commit* baseline dan perbaikan audit. Cukup jalankan:

```bash
git remote add origin https://github.com/<USERNAME>/<NAMA_REPO>.git
git push -u origin main
```

Atau gunakan skrip otomatis yang tersedia:
- **macOS / Linux / Git Bash**: `./push_to_github.sh https://github.com/<USERNAME>/<NAMA_REPO>.git`
- **Windows (CMD / PowerShell)**: `push_to_github.bat https://github.com/<USERNAME>/<NAMA_REPO>.git`
