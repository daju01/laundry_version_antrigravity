package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AddOrderBottomSheet
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GameCockpitViewModel
import com.example.viewmodel.LaundryCockpitViewModel

enum class NavGameTab(val title: String, val icon: ImageVector, val tag: String) {
    COCKPIT_3D("3D Cockpit", Icons.Default.ViewInAr, "tab_3d_cockpit"),
    PIPELINE("Pipeline", Icons.Default.LinearScale, "tab_pipeline"),
    TIM_ALAT("Tim & Alat", Icons.Default.Engineering, "tab_tim_alat"),
    KEUANGAN("Keuangan", Icons.Default.AccountBalanceWallet, "tab_keuangan"),
    PANDUAN("Panduan", Icons.Default.HelpOutline, "tab_panduan")
}

enum class WorkspaceMode(val label: String, val tag: String) {
    TYCOON_3D("🎮 3D Tycoon", "mode_tycoon_3d"),
    ERP_COCKPIT("📊 Cockpit ERP", "mode_erp_cockpit"),
    ERP_OPERASI("🧺 Order & Alur", "mode_erp_operasi"),
    ERP_KEUANGAN("💰 Analisis BEP", "mode_erp_keuangan"),
    ERP_SIMULATOR("🎛️ What-If Sim", "mode_erp_simulator"),
    ERP_SETTING("⚙️ Parameter", "mode_erp_setting")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.audio.GameSoundManager.initialize(applicationContext)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                UnifiedLaundryGameApp()
            }
        }
    }
}

@Composable
fun UnifiedLaundryGameApp(
    viewModel: GameCockpitViewModel = viewModel(),
    erpViewModel: LaundryCockpitViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val erpState by erpViewModel.uiState.collectAsStateWithLifecycle()

    var currentNavTab by remember { mutableStateOf(NavGameTab.COCKPIT_3D) }
    var currentWorkspaceMode by remember { mutableStateOf(WorkspaceMode.TYCOON_3D) }
    var tycoonDetailTab by remember { mutableIntStateOf(0) }

    // If back is pressed on another tab or ERP mode, return to main 3D Cockpit
    BackHandler(enabled = currentNavTab != NavGameTab.COCKPIT_3D || currentWorkspaceMode != WorkspaceMode.TYCOON_3D) {
        currentNavTab = NavGameTab.COCKPIT_3D
        currentWorkspaceMode = WorkspaceMode.TYCOON_3D
        tycoonDetailTab = 0
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0F172A),
        topBar = {
            WorkspaceModeSwitcherBar(
                currentMode = currentWorkspaceMode,
                onSelectMode = { mode ->
                    currentWorkspaceMode = mode
                },
                onSyncGameToErp = {
                    erpViewModel.syncFromSimulation(
                        simConfig = viewModel.toBusinessConfig(),
                        simOrders = viewModel.toBusinessOrders()
                    )
                    if (currentWorkspaceMode == WorkspaceMode.TYCOON_3D) {
                        currentWorkspaceMode = WorkspaceMode.ERP_SIMULATOR
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1E293B),
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavGameTab.values().forEach { tab ->
                    val isSelected = currentNavTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (tab == NavGameTab.PANDUAN) {
                                viewModel.openOnboarding()
                            } else {
                                currentNavTab = tab
                                viewModel.setBottomTab(tab.name)
                                when (tab) {
                                    NavGameTab.COCKPIT_3D -> {
                                        currentWorkspaceMode = WorkspaceMode.TYCOON_3D
                                        tycoonDetailTab = 0
                                    }
                                    NavGameTab.PIPELINE -> {
                                        tycoonDetailTab = 1
                                        if (currentWorkspaceMode != WorkspaceMode.TYCOON_3D) {
                                            currentWorkspaceMode = WorkspaceMode.ERP_OPERASI
                                        }
                                    }
                                    NavGameTab.TIM_ALAT -> {
                                        tycoonDetailTab = 2
                                        if (currentWorkspaceMode != WorkspaceMode.TYCOON_3D) {
                                            currentWorkspaceMode = WorkspaceMode.ERP_SETTING
                                        }
                                    }
                                    NavGameTab.KEUANGAN -> {
                                        tycoonDetailTab = 3
                                        if (currentWorkspaceMode != WorkspaceMode.TYCOON_3D) {
                                            currentWorkspaceMode = WorkspaceMode.ERP_KEUANGAN
                                        }
                                    }
                                    NavGameTab.PANDUAN -> {}
                                }
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF38BDF8),
                            selectedTextColor = Color(0xFF38BDF8),
                            indicatorColor = Color(0xFF0284C7).copy(alpha = 0.25f),
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF94A3B8)
                        ),
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF0F172A))
        ) {
            when (currentWorkspaceMode) {
                WorkspaceMode.TYCOON_3D -> {
                    MainGameCockpitScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        externalDetailTab = tycoonDetailTab,
                        onDetailTabChanged = { idx ->
                            tycoonDetailTab = idx
                            currentNavTab = when (idx) {
                                1 -> NavGameTab.PIPELINE
                                2 -> NavGameTab.TIM_ALAT
                                3 -> NavGameTab.KEUANGAN
                                else -> NavGameTab.COCKPIT_3D
                            }
                        }
                    )
                }
                WorkspaceMode.ERP_COCKPIT -> {
                    CockpitScreen(
                        state = erpState,
                        onOpenAddOrder = { erpViewModel.openAddOrderSheet() },
                        onNavigateToOperasi = {
                            currentWorkspaceMode = WorkspaceMode.ERP_OPERASI
                            currentNavTab = NavGameTab.PIPELINE
                        },
                        onNavigateToSimulator = {
                            currentWorkspaceMode = WorkspaceMode.ERP_SIMULATOR
                        }
                    )
                }
                WorkspaceMode.ERP_OPERASI -> {
                    OperasiScreen(
                        state = erpState,
                        onAdvanceOrderStatus = { erpViewModel.advanceOrderStatus(it) },
                        onDeleteOrder = { erpViewModel.deleteOrder(it) },
                        onOpenAddOrder = { erpViewModel.openAddOrderSheet() }
                    )
                }
                WorkspaceMode.ERP_KEUANGAN -> {
                    KeuanganScreen(
                        state = erpState
                    )
                }
                WorkspaceMode.ERP_SIMULATOR -> {
                    SimulatorScreen(
                        state = erpState,
                        onUpdateOrderKg = { erpViewModel.updateSimOrderKg(it) },
                        onUpdatePrice = { erpViewModel.updateSimPrice(it) },
                        onUpdateStaff = { erpViewModel.updateSimStaff(it) },
                        onUpdateWashingMachines = { erpViewModel.updateSimWashingMachines(it) },
                        onUpdateDryers = { erpViewModel.updateSimDryers(it) },
                        onUpdateRent = { erpViewModel.updateSimRent(it) },
                        onUpdateElectricity = { erpViewModel.updateSimElectricity(it) },
                        onUpdateSalary = { erpViewModel.updateSimSalary(it) },
                        onApplyScenario = { erpViewModel.applyScenario(it) },
                        onUpdateMachineInvestmentInput = { erpViewModel.updateMachineInvestmentInput(it) },
                        onUpdateTargetProfit = { erpViewModel.updateTargetProfit(it) },
                        onUpdatePricingMargin = { erpViewModel.updatePricingTargetMargin(it) },
                        onUpdatePricingCompetitor = { erpViewModel.updatePricingCompetitor(it) }
                    )
                }
                WorkspaceMode.ERP_SETTING -> {
                    SettingScreen(
                        state = erpState,
                        onSaveConfig = { erpViewModel.updateConfig(it) },
                        onResetToDefault = { erpViewModel.resetToSampleData() }
                    )
                }
            }

            if (erpState.isAddOrderSheetOpen) {
                AddOrderBottomSheet(
                    config = erpState.config,
                    onDismiss = { erpViewModel.closeAddOrderSheet() },
                    onSubmit = { name, phone, service, weight, price, deadline, status ->
                        erpViewModel.addOrder(name, phone, service, weight, price, deadline, status)
                    }
                )
            }
        }
    }
}

@Composable
private fun WorkspaceModeSwitcherBar(
    currentMode: WorkspaceMode,
    onSelectMode: (WorkspaceMode) -> Unit,
    onSyncGameToErp: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F172A))
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        WorkspaceMode.values().forEach { mode ->
            val isSelected = currentMode == mode
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isSelected) Brush.horizontalGradient(listOf(Color(0xFF0284C7), Color(0xFF0369A1)))
                        else Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .clickable { onSelectMode(mode) }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag(mode.tag)
            ) {
                Text(
                    text = mode.label,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                    color = if (isSelected) Color.White else Color(0xFF94A3B8)
                )
            }
        }

        // 1-Tap Sync from 3D Tycoon Game to ERP Business Simulator
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF065F46))
                .border(1.dp, Color(0xFF10B981), RoundedCornerShape(8.dp))
                .clickable { onSyncGameToErp() }
                .padding(horizontal = 10.dp, vertical = 5.dp)
                .testTag("btn_sync_game_to_erp")
        ) {
            Text(
                text = "🔄 Sync Game➔ERP",
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFA7F3D0)
            )
        }
    }
}
