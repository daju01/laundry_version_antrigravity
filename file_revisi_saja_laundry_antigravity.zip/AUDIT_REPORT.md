# Laporan Audit Arsitektur, Kode, & Penyempurnaan: Laundry Cockpit (Antigravity Edition)

Dokumen ini merangkum hasil penggalian mendalam (*deep-dive audit*), temuan bug kritis, kelemahan arsitektur, serta seluruh modifikasi yang telah diterapkan langsung ke dalam kode sumber proyek **Laundry Cockpit (`laundry_version_antrigravity`)**.

## 1. Ringkasan Eksekutif Audit

Proyek ini memiliki fondasi yang sangat kaya—menggabungkan **Game Simulasi 3D Isometric Laundry Tycoon** (lengkap dengan *procedural Blender-style 3D mesh shader* dan *procedural 16-bit PCM audio synthesizer*) serta **Suite Bisnis ERP & What-If Simulator** untuk pemilik usaha laundry kiloan. Namun, pada versi awal ditemukan **12 masalah kritis & struktural** yang menyebabkan sebagian besar fitur tidak dapat diakses atau gagal melakukan *recomposition* di UI.

| Kategori Audit | Status Awal | Temuan Utama | Status Setelah Modifikasi | 
| ----- | ----- | ----- | ----- | 
| **StateFlow & Recomposition** | ❌ Kritis | `_uiState.update { it.copy() }` pada `GameCockpitViewModel` ditelan oleh *structural equality* `MutableStateFlow`, sehingga mutasi `SimulationEngine` tidak memicu *recomposition* UI. | ✅ Diperbaiki dengan `stateRevision` monotonik via `emitEngineUpdate()`. | 
| **Navigasi & Layar Terputus** | ❌ Kritis | Kelima tab `NavGameTab` di `MainActivity.kt` merender `MainGameCockpitScreen` yang sama persis; **2.800+ baris kode ERP** (`CockpitScreen`, `OperasiScreen`, `KeuanganScreen`, `SimulatorScreen`, `SettingScreen`, `AddOrderSheet`) terisolasi dan tidak dapat diakses. | ✅ Diintegrasikan penuh melalui `WorkspaceModeSwitcherBar`, sinkronisasi tab bawah, dan jembatan data `Sync Game➔ERP`. | 
| **Tombol HUD Hilang** | ❌ Mayor | Parameter `onOpenShop`, `onOpenLab`, dan `onManualCloseDay` di `CockpitHeaderBar.kt` tidak pernah dirender menjadi tombol UI, sehingga pengguna tidak bisa membuka Lab atau menutup hari secara manual dari HUD. | ✅ Ditambahkan baris tombol aksi cepat (`🏪 Toko Alat & Staf`, `🧪 Uji Lab`, `🌙 Tutup Hari`) di `CockpitHeaderBar.kt`. | 
| **Sinkronisasi Mesin Cuci & Order** | ⚠️ Mayor | Siklus mesin cuci (`remainingMinutesInCycle`) dan durasi order (`minutesInCurrentPhase`) berjalan terpisah; fitur *Turbo Wash* dan *Tap Boost* mempercepat mesin tetapi order tetap tertahan. | ✅ Disinkronkan penuh antara siklus mesin cuci dan progres batch order, termasuk saat *Turbo Wash* & *Tap Boost* aktif. | 
| **Bug Slider Kuota Pagi (Lv. 3+)** | ❌ Kritis | `MorningPlanningDialog` mengunci `valueRange = 10f..40f`, sedangkan saat naik ke Level 3–5 kuota mencapai `80–200 kg`, memicu *clamp* paksa kembali ke 40 kg atau *crash* rentang `Slider`. | ✅ Rentang `Slider` kini dinamis mengikuti `growthTier.maxDailyCapacityTargetKg`. | 
| **Audio & Haptic Threading** | ⚠️ Mayor | `GameSoundManager` memanggil `Thread.sleep()` hingga 1,5 detik di `Dispatchers.Default`, tanpa batas konkurensi `AudioTrack`, dan `AndroidManifest.xml` belum memiliki izin `VIBRATE`. | ✅ Menggunakan `delay()` non-blocking di `Dispatchers.IO + SupervisorJob()`, `Semaphore(4)`, efek suara `playTapBoost()`, dan izin `VIBRATE`. | 
| **Shader 3D & Backface Culling** | ⚠️ Menengah | `Blender3DEngine.kt` hanya merotasi normal terhadap sumbu Z (tanpa *pitch* X), blok *backface culling* kosong, dan parameter `ambientOcclusion` tidak digunakan. | ✅ Normal dirotasi pada sumbu Z & X, *backface culling* aktif, dan *ambient occlusion* diterapkan berdasarkan elevasi Z. | 
| **Deteksi Bottleneck & Akuntansi** | ⚠️ Menengah | `BusinessEngine.computePipeline()` mengunci bottleneck secara statis ke `"SETRIKA"`, dan biaya booster (*Kopi* / *Promo*) di `SimulationEngine` memotong kas tanpa tercatat di `operationalExpensesToday`. | ✅ Deteksi bottleneck kini mengevaluasi utilisasi `CUCI`, `KERING`, dan `SETRIKA` secara dinamis; biaya booster tercatat akurat di laporan laba-rugi harian. | 

## 2. Detail Temuan & Modifikasi Per Komponen

### A. Perbaikan State Management & Recomposition (`GameCockpitViewModel.kt` & `LaundryCockpitViewModel.kt`)

* **Akar Masalah**: `GameUiState` menyimpan referensi objek `val engine: SimulationEngine`. Karena `SimulationEngine` dimutasi secara *in-place* (misalnya `engine.tickMinutes()`, `engine.buyEquipment()`), pemanggilan `_uiState.update { it.copy() }` menghasilkan instans `GameUiState` yang dianggap identik (`oldState == newState`) oleh `MutableStateFlow`, sehingga emisi dibatalkan dan layar Compose tidak diperbarui secara *real-time*.

* **Solusi yang Diterapkan**:

  * Menambahkan properti `val stateRevision: Long = 0L` pada `GameUiState` serta fungsi terpusat `emitEngineUpdate()` yang selalu menaikkan `stateRevision + 1L` pada setiap *tick* maupun aksi pemain.

  * Menambahkan fungsi `triggerTestStreak()` di `GameCockpitViewModel` agar tombol uji *streak* di tab Misi memicu pembaruan state melalui ViewModel (bukan memutasi `engine` langsung dari Composable).

  * Menambahkan fungsi konversi `toBusinessConfig()` dan `toBusinessOrders()` pada `GameCockpitViewModel` serta `syncFromSimulation()` pada `LaundryCockpitViewModel` untuk menyinkronkan peralatan, pekerja, kuota, kas, dan antrean pesanan dari simulasi 3D langsung ke modul kalkulator ERP.

### B. Penyatuan Navigasi & Aktivasi Seluruh Layar ERP (`MainActivity.kt` & `MainGameCockpitScreen.kt`)

* **Akar Masalah**: Pada `MainActivity.kt` lama, kelima cabang `when (currentNavTab)` memanggil `MainGameCockpitScreen(viewModel, uiState)` tanpa membedakan tab yang dipilih, dan seluruh layar analitik bisnis (`CockpitScreen`, `OperasiScreen`, `KeuanganScreen`, `SimulatorScreen`, `SettingScreen`, `AddOrderBottomSheet`) tidak pernah dipanggil.

* **Solusi yang Diterapkan**:

  * Menghubungkan tab navigasi bawah (`3D Cockpit`, `Pipeline`, `Tim & Alat`, `Keuangan`, `Panduan`) secara dua arah dengan sub-tab di `MainGameCockpitScreen` (`externalDetailTab` & `onDetailTabChanged`).

  * Menambahkan `WorkspaceModeSwitcherBar` di bagian atas layar yang memungkinkan pengguna berpindah instan antara **🎮 3D Tycoon**, **📊 Cockpit ERP**, **🧺 Order & Alur**, **💰 Analisis BEP**, **🎛️ What-If Sim**, dan **⚙️ Parameter**, lengkap dengan tombol **🔄 Sync Game➔ERP** dan modal `AddOrderBottomSheet`.

### C. Penyempurnaan HUD, Dialog Siklus Harian, & Kartu Order (`CockpitHeaderBar.kt`, `DayCycleDialogs.kt`, `OperasiScreen.kt`)

* **Tombol HUD (`CockpitHeaderBar.kt`)**:

  * Memperbaiki perhitungan batas XP level berikutnya menggunakan nilai asli dari enum `GrowthTier` (Level 5 = `2200 XP`, sebelumnya tertulis `2000 XP`).

  * Merender baris aksi manajemen (`🏪 Toko Alat & Staf`, `🧪 Uji Lab` / `🧪 Keluar Lab`, dan `🌙 Tutup Hari`) sehingga callback `onOpenShop`, `onOpenLab`, dan `onManualCloseDay` berfungsi penuh sesuai panduan tutorial.

* **Dialog Briefing Pagi (`DayCycleDialogs.kt`)**:

  * Memperbaiki batas `Slider` kuota harian dengan `val maxSliderRange = maxOf(40f, engine.growthTier.maxDailyCapacityTargetKg.toFloat() * 1.25f)` agar pemain di Level 3–5 (kapasitas 80–200 kg/hari) dapat mengatur kuota harian secara proporsional.

* **Kartu Order & Kontras Tema (`OperasiScreen.kt`, `CockpitScreen.kt`, `KeuanganScreen.kt`, `SimulatorScreen.kt`, `SettingScreen.kt`)**:

  * Menghubungkan parameter `onDelete` yang sebelumnya tidak terpakai pada `OrderCardItem` ke tombol ikon hapus (`Icons.Default.DeleteOutline`).

  * Menetapkan latar belakang eksplisit `Slate50` dan permukaan kartu `Color.White` pada seluruh layar ERP agar teks `Slate900` selalu memiliki kontras tinggi di atas container utama aplikasi.

### D. Perbaikan Logika Simulasi, Matematika Bisnis, 3D Shader, & Audio (`SimulationEngine.kt`, `BusinessEngine.kt`, `Blender3DEngine.kt`, `GameSoundManager.kt`)

* **Sinkronisasi Siklus Cuci & Interaksi Stasiun (`SimulationEngine.kt`)**:

  * Menyelaraskan durasi cuci order (`requiredMinutesInPhase = washer.cycleMinutes`) dengan siklus mesin cuci yang memprosesnya, serta memastikan `activateTurboWash()` dan `interactWithStation()` mempercepat progres order di seluruh stasiun (`MASUK`, `CUCI`, `JEMUR_KERING`, `SETRIKA`, `PACKING`, `SELESAI`).

  * Mengubah logika `addXp()` menggunakan perulangan `while` agar lonjakan XP besar dapat menaikkan beberapa level sekaligus secara akurat.

  * Mencatat pengeluaran `giveCoffeeBoost()` (Rp 25.000) dan `triggerPromoFlyer()` (Rp 40.000) ke dalam `operationalExpensesToday`, memperbarui progres misi `Q-3` secara dinamis saat reputasi berubah, dan menyalin seluruh metrik harian serta daftar misi pada `cloneForLab()`.

* **Deteksi Bottleneck Dinamis & Proteksi Pembagian Nol (`BusinessEngine.kt` & `LaundryModels.kt`)**:

  * Menghitung utilisasi kapasitas di tahap `CUCI`, `KERING`, dan `SETRIKA` secara dinamis sehingga `computePipeline()` mendeteksi bottleneck aktual berdasarkan beban dan jumlah mesin (tetap menghasilkan `"SETRIKA"` pada data sampel standar, namun otomatis berubah ke `"CUCI"` atau `"KERING"` jika mesin cuci/pengering dikurangi).

  * Menambahkan `.coerceAtLeast(...)` pada seluruh pembagi durasi siklus, jam kerja, dan volume bulanan untuk mencegah nilai `NaN` atau `Infinity`.

* **Pencahayaan 3D & Audio Synthesizer (`Blender3DEngine.kt`, `GameSoundManager.kt`, `AndroidManifest.xml`)**:

  * Merotasi normal permukaan 3D terhadap `yawRad` dan `pitchRad`, mengaktifkan *backface culling*, serta menerapkan faktor *ambient occlusion* (`aoFactor`) di `BlenderLighting.computeShading()`.

  * Mengganti `Thread.sleep()` dengan `delay()` di dalam `CoroutineScope(SupervisorJob() + Dispatchers.IO)` yang dilindungi `Semaphore(4)`, menambahkan efek suara `playTapBoost()`, dan mendaftarkan `<uses-permission android:name="android.permission.VIBRATE" />` di `AndroidManifest.xml`.