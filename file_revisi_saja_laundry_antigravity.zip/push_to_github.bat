@echo off
if "%~1"=="" (
  echo Usage: push_to_github.bat https://github.com/username/repo.git
  exit /b 1
)
git branch -M main
git remote remove origin 2>nul
git remote add origin %1
git push -u origin main
echo Berhasil di-push ke %1 (branch: main)!
